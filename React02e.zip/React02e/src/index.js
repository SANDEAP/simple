import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './index.css';
import Apical from "./apitask/apicall"
import Testapi from "./apitask/testapi"
import Apishow from './apitask/apishow';
import Apiadd from "./apitask/apiadd"

// ReactDOM.render(
  // <App />,
  // <Apical />,
  // <Testapi />,
  // <Apishow />,
  // <Apiadd />,
  // document.getElementById('root')
// );

// ReactDOM.render(
//   <React.StrictMode>
//     <Apical />
//   </React.StrictMode>,
//   document.getElementById('root')
// );




// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import App from './App';
// import Apishow from './apitask/apishow';
import { BrowserRouter } from "react-router-dom";


ReactDOM.render(
  <BrowserRouter>
    <Apishow />
  </BrowserRouter>,
  document.getElementById("root")
);