import React, { useState } from "react";
import Apicall from "./apitask/apicall";
import Testapi from "./apitask/testapi"
import Adduser from "./apitask/adduser";
import { Routes, Route } from "react-router-dom"
import Fone from "./apitask/fone";
import Ftwo  from "./apitask/ftwo";
import Apishow from "./apitask/apishow";
import Apiadd from "./apitask/apiadd";
import Apiedite from "./apitask/apiedite";
import Apidelete from "./apitask/apidelete";

// import {addding} from "./apitask/ftwo";
function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={ <Apishow/> } />
        <Route path="apiadd" element={ <Apiadd/> } />
        <Route path="apiedite" element={ <Apiedite/> } />
        <Route path="apidelete" element={ <Apidelete  b={9}/> } />       
      </Routes>
    </div>
  )
}

export default App